---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME 模組輸出匯流排
    icon: expatternprovider:mod_export_bus
categories:
- extended devices
item_ids:
- expatternprovider:mod_export_bus
---

# ME 模組輸出匯流排

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_mod_export_bus.snbt"></ImportStructure>
</GameScene>

ME 模組輸出匯流排是能以模組名稱，或是模組 ID 篩選的 <ItemLink id="ae2:export_bus" />。

如果你想同時篩選多個模組，請使用逗號「,」分隔多個模組 ID。

![PIC](../pic/mod_bus_name2.png)
