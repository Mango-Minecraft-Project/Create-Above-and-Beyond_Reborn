---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME 原材料緩衝器
    icon: expatternprovider:ingredient_buffer
categories:
- extended devices
item_ids:
- expatternprovider:ingredient_buffer
---

# ME 原材料緩衝器

<BlockImage id="expatternprovider:ingredient_buffer" scale="8"></BlockImage>

能夠儲存 36 種任何事物的方塊，無論是物品還是流體。
